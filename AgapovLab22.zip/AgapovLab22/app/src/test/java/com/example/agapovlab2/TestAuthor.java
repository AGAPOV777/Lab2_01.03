package com.example.agapovlab2;

public class TestAuthor {
    public static void main (String[] args){
        Author Ivanov = new Author("Иванов","ivan@nikuda.com");
        System.out.println(Ivanov);

        Ivanov.setEmail("ivan@nikuda.com");
        System.out.println(Ivanov);
        System.out.println("name: " + Ivanov.getName());
        System.out.println("email: " + Ivanov.getEmail());
    }
}
